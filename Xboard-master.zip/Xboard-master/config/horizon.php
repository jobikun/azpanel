<?php

use Illuminate\Support\Str;
use Linfo\Linfo;

// $lInfo = new Linfo();
// $parser = $lInfo->getParser();

return [

    /*
    |--------------------------------------------------------------------------
    | Horizon Domain
    |--------------------------------------------------------------------------
    |
    | This is the subdomain where Horizon will be accessible from. If this
    | setting is null, Horizon will reside under the same domain as the
    | application. Otherwise, this value will serve as the subdomain.
    |
    */

    'domain' => null,

    /*
    |--------------------------------------------------------------------------
    | Horizon Path
    |--------------------------------------------------------------------------
    |
    | This is the URI path where Horizon will be accessible from. Feel free
    | to change this path to anything you like. Note that the URI will not
    | affect the paths of its internal API that aren't exposed to users.
    |
    */

    'path' => 'monitor',

    /*
    |--------------------------------------------------------------------------
    | Horizon Redis Connection
    |--------------------------------------------------------------------------
    |
    | This is the name of the Redis connection where Horizon will store the
    | meta information required for it to function. It includes the list
    | of supervisors, failed jobs, job metrics, and other information.
    |
    */

    'use' => 'default',

    /*
    |--------------------------------------------------------------------------
    | Horizon Redis Prefix
    |--------------------------------------------------------------------------
    |
    | This prefix will be used when storing all Horizon data in Redis. You
    | may modify the prefix when you are running multiple installations
    | of Horizon on the same server so that they don't have problems.
    |
    */

    'prefix' => env(
        'HORIZON_PREFIX',
        Str::slug(env('APP_NAME', 'laravel'), '_') . '_horizon:'
    ),

    /*
    |--------------------------------------------------------------------------
    | Horizon Route Middleware
    |--------------------------------------------------------------------------
    |
    | These middleware will get attached onto each Horizon route, giving you
    | the chance to add your own middleware to this list or change any of
    | the existing middleware. Or, you can simply stick with this list.
    |
    */

    'middleware' => ['admin'],

    /*
    |--------------------------------------------------------------------------
    | Queue Wait Time Thresholds
    |--------------------------------------------------------------------------
    |
    | This option allows you to configure when the LongWaitDetected event
    | will be fired. Every connection / queue combination may have its
    | own, unique threshold (in seconds) before this event is fired.
    |
    */

    'waits' => [
        'redis:default' => 60,
    ],

    /*
    |--------------------------------------------------------------------------
    | Job Trimming Times
    |--------------------------------------------------------------------------
    |
    | Here you can configure for how long (in minutes) you desire Horizon to
    | persist the recent and failed jobs. Typically, recent jobs are kept
    | for one hour while all failed jobs are stored for an entire week.
    |
    */

    'trim' => [
        'recent' => 60,
        'pending' => 60,
        'completed' => 60,
        'recent_failed' => 10080,
        'failed' => 10080,
        'monitored' => 10080,
    ],

    /*
    |--------------------------------------------------------------------------
    | Metrics
    |--------------------------------------------------------------------------
    |
    | Here you can configure how many snapshots should be kept to display in
    | the metrics graph. This will get used in combination with Horizon's
    | `horizon:snapshot` schedule to define how long to retain metrics.
    |
    */

    'metrics' => [
        'trim_snapshots' => [
            'job' => 24,
            'queue' => 24,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Fast Termination
    |--------------------------------------------------------------------------
    |
    | When this option is enabled, Horizon's "terminate" command will not
    | wait on all of the workers to terminate unless the --wait option
    | is provided. Fast termination can shorten deployment delay by
    | allowing a new instance of Horizon to start while the last
    | instance will continue to terminate each of its workers.
    |
    */

    'fast_termination' => false,

    /*
    |--------------------------------------------------------------------------
    | Memory Limit (MB)
    |--------------------------------------------------------------------------
    |
    | This value describes the maximum amount of memory the Horizon worker
    | may consume before it is terminated and restarted. You should set
    | this value according to the resources available to your server.
    |
    */

    'memory_limit' => 256,

    /*
    |--------------------------------------------------------------------------
    | Queue Worker Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may define the queue worker settings used by your application
    | in all environments. These supervisors and settings handle all your
    | queued jobs and will be provisioned by Horizon during deployment.
    |
    */

    'environments' => [
        'production' => [
            'data-pipeline' => [
                'connection' => 'redis',
                'queue' => ['traffic_fetch', 'stat', 'user_alive_sync'],
                'balance' => 'auto',
                'autoScalingStrategy' => 'time',
                'minProcesses' => 1,
                'maxProcesses' => (int) env('HORIZON_DATA_PIPELINE_MAX', 8),
                'memory' => (int) env('HORIZON_WORKER_MEMORY_MB', 128),
                'maxTime' => (int) env('HORIZON_WORKER_MAX_TIME', 3600),
                'maxJobs' => (int) env('HORIZON_WORKER_MAX_JOBS', 1000),
                'balanceCooldown' => 1,
                'tries' => 3,
                'timeout' => 30,
            ],
            'business' => [
                'connection' => 'redis',
                'queue' => ['default', 'order_handle'],
                'balance' => 'simple',
                'minProcesses' => 1,
                'maxProcesses' => (int) env('HORIZON_BUSINESS_MAX', 3),
                'memory' => (int) env('HORIZON_WORKER_MEMORY_MB', 128),
                'maxTime' => (int) env('HORIZON_WORKER_MAX_TIME', 3600),
                'maxJobs' => (int) env('HORIZON_WORKER_MAX_JOBS', 1000),
                'tries' => 3,
                'timeout' => 30,
            ],
            'notification' => [
                'connection' => 'redis',
                'queue' => ['send_email', 'send_telegram', 'send_email_mass', 'node_sync'],
                'balance' => 'auto',
                'autoScalingStrategy' => 'size',
                'minProcesses' => 1,
                'maxProcesses' => (int) env('HORIZON_NOTIFICATION_MAX', 3),
                'memory' => (int) env('HORIZON_WORKER_MEMORY_MB', 128),
                'maxTime' => (int) env('HORIZON_WORKER_MAX_TIME', 3600),
                'maxJobs' => (int) env('HORIZON_WORKER_MAX_JOBS', 1000),
                'tries' => 3,
                'timeout' => 60,
                'backoff' => [3, 10, 30],
            ],
        ],
        'local' => [
            'Xboard' => [
                'connection' => 'redis',
                'queue' => [
                    'default',
                    'order_handle',
                    'traffic_fetch',
                    'stat',
                    'send_email',
                    'send_email_mass',
                    'send_telegram',
                    'user_alive_sync',
                    'node_sync'
                ],
                'balance' => 'auto',
                'minProcesses' => 1,
                'maxProcesses' => 5,
                'tries' => 1,
                'timeout' => 60,
                'balanceCooldown' => 3,
            ],
        ],
    ],
];
